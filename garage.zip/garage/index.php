<?php session_start();
 include('dbcon.php'); ?>
 <!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Garage Admin Login</title>
    <link rel="stylesheet" href="css/login.css">
</head>

<body>
    <h1 style="color: black;">Welcome to Garage Management System</h1>
    <div class="loginbox">
        <div class="login-box">
            <h2>Login</h2>
            <form id="loginform" method="POST" class="form-vertical" action="#">
                <label for="username">Username :</label>
                <input type="text" name="user" placeholder="Username" required />
                <label for="password">Password : </label>
                <input type="password" name="pass" placeholder="Password" required />
                <div class="form-actions center">
                    <!-- <span class="pull-right"><a type="submit" href="index.html" class="btn btn-success" /> Login</a></span> -->
                    <!-- <input type="submit" class="button" title="Log In" name="login" value="Admin Login"></input> -->
                    <button type="submit" class="btn" title="Log In" name="login"
                        value="Admin Login">Admin Login</button>
                </div>
            </form>
            <?php
            if (isset($_POST['login']))
                {
                    $username = mysqli_real_escape_string($con, $_POST['user']);
                    $password = mysqli_real_escape_string($con, $_POST['pass']);

                    $password = md5($password);
                    
                    $query 		= mysqli_query($con, "SELECT * FROM admin WHERE  password='$password' and username='$username'");
                    $row		= mysqli_fetch_array($query);
                    $num_row 	= mysqli_num_rows($query);
                    
                    if ($num_row > 0) 
                        {			
                            $_SESSION['user_id']=$row['user_id'];
                            header('location:admin/index.php');
                            
                        }
                    else
                        {
                            echo "<div class='alert alert-danger alert-dismissible' role='alert'>
                            Invalid Username and Password
                            <button type='button' class='close' data-dismiss='alert' aria-label='Close'>
                                <span aria-hidden='true'>&times;</span>
                            </button>
                            </div>";
                        }
                }
        ?>

        </div>
    </div>

</body>

</html>