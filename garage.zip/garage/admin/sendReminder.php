<?php
include "dbcon.php";

session_start();
if (!isset($_SESSION['user_id'])) {
    header('location:../index.php');
}

if (isset($_GET['id'])) {
    $id = $_GET['id'];

    // Prepare SQL query to retrieve data
    $sql = "SELECT fullname, contact, model FROM customers WHERE user_id = $id";

    $stmt = $con->prepare($sql);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $name = $row["fullname"];
        $contact = $row["contact"];
        $vehicleModel = $row["model"];

        require __DIR__ . '/vendor/autoload.php'; // Update the path here

        $client = new \Google_Client();
        $client->setApplicationName('Google Sheets with Primo');
        $client->setScopes([\Google_Service_Sheets::SPREADSHEETS]);
        $client->setAccessType('offline');
        $client->setAuthConfig(__DIR__ . '/credentials.json');

        $service = new Google_Service_Sheets($client);
        $spreadsheetId = "1LxAnxkOt4x-3ZQxUdBq8RDLNGD4qB9VXKHJW6h9fQgI";

        $range = "sms"; // Sheet name

        $values = [
            [$name, $contact, $vehicleModel],
        ];
        $body = new Google_Service_Sheets_ValueRange([
            'values' => $values
        ]);
        $params = [
            'valueInputOption' => 'RAW'
        ];

        $result = $service->spreadsheets_values->append(
            $spreadsheetId,
            $range,
            $body,
            $params
        );

        if ($result->updates->updatedRows == 1) {
          echo '<script>alert("Selected Customer Has Been Added To Reminder List")</script>';
          echo '<script>window.location.href = "reminder.php";</script>';
        } else {
            echo "Fail";
        }
    } else {
        echo "Some Error appeared";
        }
        }
        $qry1="UPDATE customers SET reminder = '1' where user_id=$id";
        $result1=mysqli_query($con,$qry1);
      $con->close();
?>







